#include <iostream>
#include <fstream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <vector>
#include <algorithm>
#include <filesystem>
#include <direct.h>

#pragma comment(lib, "Ws2_32.lib")

#define SERVER_PORT "5000"
#define BUFFER_SIZE 1024
#define SOURCE_FOLDER "Input"
#define FILE_LIST "list_input.txt"

// Vector to store file names and their sizes in bytes
std::vector<std::pair<std::string, int64_t>> files;

// Function to load file names and sizes from the file list
void load_files()
{
    std::ifstream infile(FILE_LIST);
    std::string filename;
    int64_t filesize;
    std::string size_unit;

    while (infile >> filename >> filesize >> size_unit)
    {
        std::ifstream file(SOURCE_FOLDER + std::string("/") + filename, std::ios::binary | std::ios::ate);
        filesize = file.tellg();
        files.push_back({filename, filesize});
    }
}

std::string convertFileSize(int64_t filesize)
{
    std::string size_str;
    if (filesize >= 1024 * 1024 * 1024)
    {
        size_str = std::to_string(filesize / (1024 * 1024 * 1024)) + " GB";
    }
    else if (filesize >= 1024 * 1024)
    {
        size_str = std::to_string(filesize / (1024 * 1024)) + " MB";
    }
    else if (filesize >= 1024)
    {
        size_str = std::to_string(filesize / 1024) + " KB";
    }
    else
    {
        size_str = std::to_string(filesize) + " B";
    }
    return size_str;
}

// Function to read files in the Source folder and write to list_input.txt if it doesn't exist
void update_file_list()
{
    if (std::filesystem::exists(FILE_LIST))
    {
        return;
    }

    std::vector<std::pair<std::string, int64_t>> file_entries;
    for (const std::filesystem::directory_entry &entry : std::filesystem::directory_iterator(SOURCE_FOLDER))
    {
        if (entry.is_regular_file())
        {
            std::string filename = entry.path().filename().string();
            int64_t filesize = std::filesystem::file_size(entry.path());
            file_entries.push_back({filename, filesize});
        }
    }

    if (file_entries.empty())
    {
        return;
    }

    std::ofstream outfile(FILE_LIST);

    for (const std::pair<std::string, int64_t> &file_entry : file_entries)
    {
        outfile << file_entry.first << " " << convertFileSize(file_entry.second) << std::endl;
    }

    outfile.close();
}
// Function to handle client requests
void handle_client(SOCKET client_socket)
{
    char buffer[BUFFER_SIZE];

    // Send the list of files available on the server
    std::string file_list;
    for (const auto &file : files)
    {
        file_list += file.first + " (" + convertFileSize(file.second) + ")\n";
    }
    send(client_socket, file_list.c_str(), file_list.size(), 0);

    while (true)
    {
        int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0)
        {
            break;
        }
        buffer[bytes_received] = '\0';
        std::string requested_file(buffer);

        // Remove any trailing newline or carriage return characters
        requested_file.erase(std::remove(requested_file.begin(), requested_file.end(), '\n'), requested_file.end());
        requested_file.erase(std::remove(requested_file.begin(), requested_file.end(), '\r'), requested_file.end());

        // Find the requested file in the list
        auto it = std::find_if(files.begin(), files.end(), [&requested_file](const std::pair<std::string, int64_t> &p)
                               { return p.first == requested_file; });

        if (it != files.end())
        {
            // Open the requested file
            std::ifstream file(SOURCE_FOLDER + std::string("/") + requested_file, std::ios::binary | std::ios::ate);
            if (file.is_open())
            {
                int64_t file_size = file.tellg();
                file.seekg(0, std::ios::beg);
                std::string file_size_str = std::to_string(file_size) + "\n";
                send(client_socket, file_size_str.c_str(), file_size_str.size(), 0);

                int64_t total_sent = 0;
                bool client_disconnected = false;
                while (file_size > 0)
                {
                    int bytes_to_send = (((file_size) < ((int64_t)1024)) ? (file_size) : ((int64_t)1024));
                    file.read(buffer, bytes_to_send);
                    int bytes_sent = send(client_socket, buffer, bytes_to_send, 0);
                    if (bytes_sent == SOCKET_ERROR)
                    {
                        std::cerr << "\nClient disconnected while sending " << requested_file << std::endl;
                        client_disconnected = true;
                        break;
                    }
                    file_size -= bytes_sent;
                    total_sent += bytes_sent;
                    std::cout << "\rSending " << requested_file << " .... " << (static_cast<int>(total_sent * 100 / it->second)) << "%" << std::flush;
                }
                if (!client_disconnected)
                {
                    std::cout << std::endl;
                }
                file.close();
            }
            else
            {
                std::cerr << "Failed to open file: " << requested_file << std::endl;
            }
        }
        else
        {
            // Send "File not found" message if the file is not in the list
            std::string not_found = "File not found";
            send(client_socket, not_found.c_str(), not_found.size(), 0);
        }
    }
    closesocket(client_socket);
}

int main()
{
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0)
    {
        std::cerr << "WSAStartup failed: " << result << std::endl;
        return 1;
    }

    // Create file_list directory if it doesn't exist
    if (_mkdir(SOURCE_FOLDER) != 0 && errno != EEXIST)
    {
        std::cerr << "Failed to create output directory" << std::endl;
        WSACleanup();
        return 1;
    }

    // Create list_input.txt
    update_file_list();

    // Load files from the file list
    load_files();

    struct addrinfo hints, *server_info;
    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    result = getaddrinfo(NULL, SERVER_PORT, &hints, &server_info);
    if (result != 0)
    {
        std::cerr << "getaddrinfo failed: " << result << std::endl;
        WSACleanup();
        return 1;
    }

    SOCKET server_socket = socket(server_info->ai_family, server_info->ai_socktype, server_info->ai_protocol);
    if (server_socket == INVALID_SOCKET)
    {
        std::cerr << "Socket creation failed: " << WSAGetLastError() << std::endl;
        freeaddrinfo(server_info);
        WSACleanup();
        return 1;
    }

    result = bind(server_socket, server_info->ai_addr, (int)server_info->ai_addrlen);
    if (result == SOCKET_ERROR)
    {
        std::cerr << "Bind failed: " << WSAGetLastError() << std::endl;
        freeaddrinfo(server_info);
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(server_info);

    result = listen(server_socket, SOMAXCONN);
    if (result == SOCKET_ERROR)
    {
        std::cerr << "Listen failed: " << WSAGetLastError() << std::endl;
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }

    std::cout << "Server is listening on port " << SERVER_PORT << std::endl;

    while (true)
    {
        SOCKET client_socket = accept(server_socket, NULL, NULL);
        if (client_socket == INVALID_SOCKET)
        {
            std::cerr << "Accept failed: " << WSAGetLastError() << std::endl;
            closesocket(server_socket);
            WSACleanup();
            return 1;
        }
        else
        {
            std::cout << "Client connected.\n";
        }
        handle_client(client_socket);
        std::cout << "Client disconnected.\n\n";
    }

    closesocket(server_socket);
    WSACleanup();
    return 0;
}