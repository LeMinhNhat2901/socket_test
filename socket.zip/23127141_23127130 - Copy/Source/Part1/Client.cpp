#include <iostream>
#include <fstream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <direct.h>      // For _mkdir
#include <vector>        // For std::vector
#include <unordered_set> // For std::unordered_set
#include <filesystem>    // For std::filesystem
#include <csignal>       // For signal handling
#include <unistd.h>      // For sleep

#pragma comment(lib, "Ws2_32.lib")

#define SERVER_PORT "5000"
#define BUFFER_SIZE 1024
#define OUTPUT_FOLDER "Output"

std::unordered_set<std::string> processed_files;
std::filesystem::file_time_type last_write_time;
size_t last_processed_line = 0;
bool running = true;
bool first_time = true;
SOCKET client_socket;
std::string server_host;

// Signal handler for "Ctrl + C"
void signal_handler(int signal)
{
    if (signal == SIGINT)
    {
        std::cout << "\nShutting down..." << std::endl;
        running = false;
        closesocket(client_socket);
        WSACleanup();
        exit(0);
    }
}

// Load the list of new files to download from input.txt starting from the last processed line
std::vector<std::string> load_new_files()
{
    std::ifstream infile("input.txt");
    std::string file;
    std::vector<std::string> new_files;
    size_t current_line = 0;

    while (std::getline(infile, file))
    {
        if (current_line >= last_processed_line)
        {
            new_files.push_back(file);
        }
        current_line++;
    }

    last_processed_line = current_line;
    infile.close();
    return new_files;
}

// Check if a file already exists in the output folder
bool file_exists(const std::string &filename)
{
    std::string output_path = std::string(OUTPUT_FOLDER) + "/" + filename;
    return std::filesystem::exists(output_path);
}

// Download the requested file from the server
void download_file(const std::string &filename, SOCKET client_socket)
{
    char buffer[BUFFER_SIZE];
    int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
    if (bytes_received > 0)
    {
        buffer[bytes_received] = '\0';
        std::string response(buffer);

        if (response == "File not found")
        {
            std::cout << "File not found: " << filename << std::endl;
            return;
        }

        try
        {
            // std::cout << "Received file size response: " << response << std::endl; // Log the response
            int64_t file_size = std::stoll(response);
            std::string output_path = std::string(OUTPUT_FOLDER) + "/" + filename; // Use std::string for concatenation

            std::ofstream file(output_path, std::ios::binary);
            if (file.is_open())
            {
                int64_t total_received = 0;
                while (total_received < file_size)
                {
                    bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
                    if (bytes_received <= 0)
                    {
                        break;
                    }
                    file.write(buffer, bytes_received);
                    total_received += bytes_received;
                    std::cout << "\rDownloading " << filename << " .... " << (total_received * 100 / file_size) << "%" << std::flush;
                }
                file.close();
                std::cout << "\rDownloading " << filename << " .... 100%" << std::endl;
                processed_files.insert(filename);
            }
            else
            {
                std::cerr << "Failed to open file for writing: " << output_path << std::endl;
            }
        }
        catch (const std::invalid_argument &e)
        {
            std::cerr << "Invalid file size received for file: " << filename << std::endl;
        }
    }
    else
    {
        std::cerr << "Failed to receive file size from server." << std::endl;
    }
}

// Print the list of files available on the server
void print_server_files(SOCKET client_socket)
{
    char buffer[BUFFER_SIZE];
    int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
    if (bytes_received > 0)
    {
        buffer[bytes_received] = '\0';
        std::string file_list(buffer);
        std::cout << "Files available on the server:" << std::endl;
        std::cout << file_list << std::endl;
    }
    else
    {
        std::cerr << "Failed to receive file list from server." << std::endl;
    }
}

int main()
{
    // Register signal handler for "Ctrl + C"
    signal(SIGINT, signal_handler);

    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0)
    {
        std::cerr << "WSAStartup failed: " << result << std::endl;
        return 1;
    }

    // Prompt user for server IP address
    std::cout << "Enter the server IP address: ";
    std::cin >> server_host;

    // Create output directory if it doesn't exist
    if (_mkdir(OUTPUT_FOLDER) != 0 && errno != EEXIST)
    {
        std::cerr << "Failed to create output directory" << std::endl;
        WSACleanup();
        return 1;
    }

    while (running)
    {
        client_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (client_socket == INVALID_SOCKET)
        {
            std::cerr << "Socket creation failed: " << WSAGetLastError() << std::endl;
            return 1;
        }

        struct addrinfo hints, *server_info;
        ZeroMemory(&hints, sizeof(hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;

        result = getaddrinfo(server_host.c_str(), SERVER_PORT, &hints, &server_info);
        if (result != 0)
        {
            std::cerr << "getaddrinfo failed: " << gai_strerror(result) << std::endl;
            closesocket(client_socket);
            return 1;
        }

        result = connect(client_socket, server_info->ai_addr, (int)server_info->ai_addrlen);
        if (result == SOCKET_ERROR)
        {
            std::cerr << "Connect failed: " << WSAGetLastError() << std::endl;
            freeaddrinfo(server_info);
            closesocket(client_socket);
            return 1;
        }

        freeaddrinfo(server_info);

        // Print the list of files available on the server
        print_server_files(client_socket);

        while (running)
        {
            // Check if input.txt has changed
            std::filesystem::file_time_type current_write_time = std::filesystem::last_write_time("input.txt");
            if (current_write_time != last_write_time)
            {
                last_write_time = current_write_time;
                if (!first_time)
                    std::cout << "Found changes in input.txt" << std::endl;

                // Read the list of new files to download
                std::vector<std::string> new_files = load_new_files();

                for (const std::string &filename : new_files)
                {
                    if (file_exists(filename))
                    {
                        std::cout << filename << " already exists" << std::endl;
                        processed_files.insert(filename);
                    }
                    else
                    {
                        // Request the file
                        send(client_socket, filename.c_str(), filename.size(), 0);
                        download_file(filename, client_socket);
                    }
                }
                if (first_time)
                    first_time = false;
            }
        }

        closesocket(client_socket);
    }

    WSACleanup();
    return 0;
}