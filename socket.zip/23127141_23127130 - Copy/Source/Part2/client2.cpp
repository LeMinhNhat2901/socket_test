#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <winsock2.h> //---contain most of winsock function, struct,...
#include <ws2tcpip.h> //---definitions introduced in the winsock2 protocol for TCPIP
#include <iostream>
#include <iphlpapi.h> //---use if app using IP Helper APIs, place after the winsock2.h line
#include <windows.h>
#include <fstream>
#include <vector>
#include <stdint.h>
#include <sstream>
#include <cstring>
#include <thread>
#include <windows.h>
#include <csignal>
#include <filesystem>
#include <direct.h>

#define OUTPUT_FOLDER "Output\\"

//-----make the linker indicate the Ws2_32.lib file
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

const char* DEFAULT_PORT = "27019"; //--port for client connect
const int NORMAL_BUFLEN= 10000; // 10KB
const int MEDIUM_BUFLEN = 20000; // 20KB 
const int HIGH_BUFLEN = 40000; // 40KB 
const int CRITICAL_BUFLEN = 100000; // 100KB
const int SEND_BUFLEN = 400000; //400KB
int last_processed_line = 0;
COORD startPos;
SOCKET partnerSocket;
bool running = true;

struct File
{
    char* filename = NULL;
    int sizeMB = 0;
    char* status = NULL;
};

void signal_handler(int signal)
{
    if (signal == SIGINT)
    {
        std::cout << "\nShutting down..." << std::endl;
        running = false;
        closesocket(SIGINT);
        WSACleanup();
        exit(0);
    }
}

bool sendInt(int num, SOCKET Partner) 
{
    int iResult = send(Partner, (char*)&num, sizeof(num), 0);
    
    if (iResult == SOCKET_ERROR) 
    {
        std::cerr << "sendInt() failed: " << WSAGetLastError() << '\n';
        return false;
    }
    return true;
}

bool file_exists(char* filename)
{
    std::string output_path = std::string(OUTPUT_FOLDER) + filename;
    return std::filesystem::exists(output_path);
}

int receiveInt(SOCKET Partner) 
{
    int num;
    int iResult = recv(Partner, (char*)&num, sizeof(num), 0);
    if (iResult == SOCKET_ERROR) 
    {
        std::cerr << "recv() int failed: " << WSAGetLastError() << '\n';
        return WSAGetLastError();
    }
    return num;
}

char* receiveMessage(SOCKET Partner) {
    int messageLength;
    int iResult = recv(Partner, (char*)&messageLength, sizeof(messageLength), 0);
    if (iResult <= 0) {
        std::cerr << "recvMsg() failed for length: " << WSAGetLastError() << '\n';
        return nullptr;
    }
    messageLength = ntohl(messageLength); // Convert from network byte order

    char* buffer = new char[messageLength];
    iResult = recv(Partner, buffer, messageLength, 0);
    if (iResult <= 0) {
        std::cerr << "recvMsg() failed for message: " << WSAGetLastError() << '\n';
        delete[] buffer;
        return nullptr;
    }
    return buffer;
}


void cleanupFiles(std::vector<File>& database) 
{
    for (auto& file : database) {
        delete[] file.filename;
        delete[] file.status;
    }
    database.clear();
}

void printListofFile(std::vector<File> database)
{
    for (int i = 0; i < database.size(); ++i)
    {
        std::cout << database[i].filename << ' ' << database[i].sizeMB << "MB " << '\n';
    }
}

std::vector<File> receiveListofFile(SOCKET Partner) 
{
    std::vector<File> database;
    int size = receiveInt(Partner);

    for (int i = 0; i < size; ++i) 
    {
        File data;
        data.filename = receiveMessage(Partner);
        data.sizeMB = receiveInt(Partner);
        if (data.filename == nullptr) 
        {
            std::cerr << "Failed to receive file data\n";
            // Handle cleanup
            cleanupFiles(database);
            return {};
        }
        database.push_back(data);
    }
    return database;
}

COORD getCurrentCursorLinePosition()
{
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    return csbi.dwCursorPosition;
}

void gotoXY(int x, int y, int baseY)
{
    COORD coord = {static_cast<SHORT>(x), static_cast<SHORT>(y + baseY)};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

int getProgress(int recv, int total)
{
    float percent = float(recv) / float(total);
    percent *= 100;
    return (int) percent;
}

void printProgressBar(std::string fileName, int progress, int line) 
{
    int totalWidth = 40;
    int barWidth = (progress * totalWidth) / 100;
    std::string bar = std::string(barWidth, '|') + std::string(totalWidth - barWidth, '_');

    gotoXY(0, line, startPos.Y);
    std::cout << fileName << " loading" << bar << " " << progress << "%" << std::flush;
}

void receiveFile(SOCKET Partner, const std::string& filename, int line)
{
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Failed to create required file: " << filename << '\n';
        return;
    }

    // Receive file size first
    int fileSize = receiveInt(Partner); // Assuming receiveInt() is implemented to handle int64_t
    if (fileSize <= 0)
    {
        std::cerr << "Invalid file size received.\n";
        return;
    }

    char buffer[512];
    int64_t receivedBytes = 0;
    int iResult;
    while (receivedBytes < fileSize)
    {
        iResult = recv(Partner, buffer, sizeof(buffer), 0);
        if (iResult > 0)
        {
            file.write(buffer, iResult);
            receivedBytes += iResult;
            printProgressBar(filename, getProgress(receivedBytes, fileSize), line);
        }
        else if (iResult == 0)
        {
            std::cout << "Connection closed by server.\n";
            break;
        }
        else
        {
            std::cerr << "recv() failed: " << WSAGetLastError() << '\n';
            break;
        }

    }
    file.close();
}

/*bool receiveFilesFromSingleBuffer(SOCKET Partner, const std::vector<std::pair<char*, int>>& fileList) 
{
    std::cout << "---Receiving---\n";
    char* mainBuffer = new char[SEND_BUFLEN];

    int offset = 0;
    int bytesReceived = recv(Partner, mainBuffer, SEND_BUFLEN, 0);
    if (bytesReceived <= 0) 
        std::cerr << "recv() failed: " << WSAGetLastError() << '\n';

    for (int i = 0; i < fileList.size(); ++i)
    {
        std::pair<char*, int> filePair = fileList[i];
        std::ofstream file(filePair.first, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Failed to open file: " << filePair.first << '\n';
            return false;
        }
        std::cout << filePair.first << ' ';

        int chunkSize = filePair.second;
        while (chunkSize > 0 && offset < bytesReceived) 
        {
            int bytesToWrite = std::min(chunkSize, bytesReceived - offset);
            file.write(mainBuffer + offset, bytesToWrite);
            //printProgressBar(filePair.first, getProgress(bytesToWrite, filePair.second), i);
            chunkSize -= bytesToWrite;
            offset += bytesToWrite;

            // If the current buffer is exhausted, receive more data
            if (offset >= bytesReceived && chunkSize > 0) 
            {
                bytesReceived = recv(Partner, mainBuffer, SEND_BUFLEN, 0);
                if (bytesReceived <= 0) 
                {
                    std::cerr << "recv() failed: " << WSAGetLastError() << '\n';
                    file.close();
                    return false;
                }
                offset = 0;
            }
        }
        file.close();
    }
    return true;
}
*/

bool isAllFileSent(std::vector<bool> list)
{
    for (bool val: list)
        if (!val) return false;
    return true;
}

std::ofstream openFileInAppendMode(char* filename)
{
    std::string output_path = std::string(OUTPUT_FOLDER) + filename;
    std::ofstream file(output_path, std::ios::out | std::ios::binary | std::ios::app);
    
    if (!file.is_open())
    {
        file.open(filename, std::ios::out | std::ios::binary);
    }
    return file;
}

char* splitCstring(char* cstr, int left, int length)
{
    char* newcstr = new char[length + 1];
    for (int i = left; i < left + length; ++i)
    {
        newcstr[i - left] = cstr[i];
    }
    newcstr[length] = '\0';
    return newcstr;
}

bool receiveFilesFromSingleBuffer(SOCKET Partner, const std::vector<std::pair<char*, int>>& fileList) 
{
    char* mainBuffer = new char[SEND_BUFLEN];
    int offset = 0;
    std::vector<bool> isDone(fileList.size(), false);
    std::vector<int> tracking(fileList.size(), 0), fileBytesDown, indexOfFile;

    while(!isAllFileSent(isDone))
    {
        //receive number of File being send in buffer
        int numOfFile = receiveInt(Partner); //std::cout << "#num of chunk: "<< numOfFile << '\n';
        for (int i = 0; i < numOfFile; ++i)
        {
            //receive index of file and bytes of that file in buffer
            indexOfFile.push_back(receiveInt(Partner)); 
            fileBytesDown.push_back(receiveInt(Partner)); 
        }

        int bytesReceived = recv(Partner, mainBuffer, SEND_BUFLEN, 0);
        if (bytesReceived <= 0) 
        {
            std::cerr << "recv() buffer failed: " << WSAGetLastError() << '\n';
            delete[] mainBuffer;
            return false;
        }

        for (int i = 0; i < indexOfFile.size(); ++i)
        {
            int fileIndex = indexOfFile[i];
            std::ofstream file = openFileInAppendMode(fileList[fileIndex].first);
            
            char* writeBuf = splitCstring(mainBuffer, offset, fileBytesDown[i]);

            //std::cout << fileList[fileIndex].first << " : " << fileBytesDown[i] << '\n'; 
            file.write(writeBuf, fileBytesDown[i]);

            offset += fileBytesDown[i];
            tracking[fileIndex] += fileBytesDown[i]; //fileList[fileIndex].second
            printProgressBar(fileList[fileIndex].first, getProgress(tracking[fileIndex], i), fileIndex);
            
            if (tracking[fileIndex] == fileList[fileIndex].second) 
            {
                //std::cout << fileList[fileIndex].first << " done\n";
                isDone[fileIndex] = true;
            }
            delete[] writeBuf;
            if (isAllFileSent(isDone)) break;
        }
        fileBytesDown.clear();
        indexOfFile.clear();
        offset = 0;
        if (isAllFileSent(isDone)) break;
    }

    startPos = getCurrentCursorLinePosition();
    std::cout << "\nFinished\n";
    delete[] mainBuffer;
    return true;
}

std::vector<File> readClientFile(std::string filename)
{
    std::ifstream fin(filename);
    if (!fin.is_open())
    {
        std::cerr << "Failed to open client list\n";
        return {};
    }

    int cur_line = 0;

    std::vector<File> database;
    std::string line;
    while (getline(fin, line)) 
    {
        if (cur_line < last_processed_line) cur_line++;
        else
        {
            std::istringstream iss(line);
            std::string fileNameStr, statusStr;

            if (!(iss >> fileNameStr >> statusStr)) 
            {
                continue; // Skip lines that do not match the format
            }

            File data;
            data.filename = new char[fileNameStr.size() + 1];
            strcpy(data.filename, fileNameStr.c_str());
            data.status = new char[statusStr.size() + 1];
            strcpy(data.status, statusStr.c_str());
            if (!file_exists(data.filename)) 
            {
                database.push_back(data);
            }
        } 
    }
    last_processed_line = cur_line;
    fin.close();
    return database;
}

std::vector<File> getDifferentList(std::vector<File> org_list, std::vector<File> new_list)
{
    std::vector<File> dif_list;
    if (new_list.size() > org_list.size())
        for (int i = org_list.size(); i < new_list.size(); ++i)
        {
            dif_list.push_back(new_list[i]);
        }
    return dif_list;
}

bool sendMessage(const char* message, SOCKET Partner) {
    int messageLength = static_cast<int>(std::strlen(message)) + 1;
    int lengthToSend = htonl(messageLength); // Convert length to network byte order

    // Send length of the message
    int iResult = send(Partner, (char*)&lengthToSend, sizeof(lengthToSend), 0);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Send length failed with error: " << WSAGetLastError() << '\n';
        closesocket(Partner);
        WSACleanup();
        return false;
    }

    // Send the actual message
    iResult = send(Partner, message, messageLength, 0);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Send message failed with error: " << WSAGetLastError() << '\n';
        closesocket(Partner);
        WSACleanup();
        return false;
    }
    return true;
}

bool downloadFileFromServer2(const std::vector<File>& list, SOCKET Partner)
{
    //send number of file requested 
    std::cout << "--Downloading\n";
    int size = list.size();
    sendInt(size, Partner);
    
    startPos = getCurrentCursorLinePosition();
    std::vector<std::pair<char*, int>> fileList;

    for (int i = 0; i < list.size(); ++i)
    {
        File file = list[i];
        //sending the file name for server
        if (!sendMessage(file.filename, Partner))
        {
            std::cerr << "Error sending filename to server\n";
            return false;
        }

        //send the status of the file to server
        if (!sendMessage(file.status, Partner))
        {
            std::cerr << "Error sending status to server\n"; 
            return false;
        }

        //receive the chunk size from server
        int fileSize = receiveInt(Partner);
        if (fileSize != 0)
        {
            std::cout << "After get file size: " << file.filename << " - " << fileSize <<'\n'; 
            fileList.emplace_back(file.filename, fileSize);
        }
        else std::cout << "Cannot download file not in server database\n";
        
    }

    if (!receiveFilesFromSingleBuffer(Partner, fileList));
    {
        std::cerr << "Error receiving files from server\n";
        return false;
    }
    
    return true;
}


void printClientList(std::vector<File> list)
{
    for (int i = 0; i < list.size(); ++i)
        std::cout << list[i].filename << ' ' << list[i].status << '\n';
}

//client.exe <server IP address>
int main(int argc, char** argv)
{
    std::cout << "----------------------Client-------------\n";
    //--create WSA object 
    WSADATA wsaData;

    int iResult;
    //--- initialize winsock and check if init complete
    //--- WSAStartup function use WS2_32.dll.
    //--- MAKEWORD for WSA use the 2.2 version of winsock

    if (argc != 2)
    {
        std::cout << "wrong command line\n";
        std::cout << "<*.exe> <Server IP address> ";
        return 1;
    }

    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData); //result of the start up
    if (iResult != 0)
    {
        std::cout << "WSAStartup failed: " << iResult << '\n';
        return 1;
    }

    if (_mkdir(OUTPUT_FOLDER) != 0 && errno != EEXIST)
    {
        std::cerr << "Failed to create output directory" << std::endl;
        WSACleanup();
        return 1;
    }

    struct addrinfo *result = NULL, *ptr = NULL, hints;
    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_UNSPEC; //--specify IPv4 address
    hints.ai_socktype = SOCK_STREAM; //--specify stream socket
    hints.ai_protocol = IPPROTO_TCP;//--use TCP Protocol

    iResult = getaddrinfo(argv[1], DEFAULT_PORT, &hints, &result);
    if (iResult != 0)
    {
        std::cout << "Getaddrinfo failed: " << iResult << '\n';
        WSACleanup();
        return 1;
    }

    SOCKET ConnectSocket = INVALID_SOCKET;//server socket to listen client
    ptr = result;
    ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);   

    //---attempt to connect to the first address returned by
    //---the call to getaddrinfo
    if (ConnectSocket == INVALID_SOCKET)
    {
        std::cout << "Error at socket(): " << WSAGetLastError() << '\n';
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }


    //--------------------------------connect server-----------------------------------------
    iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
    if (iResult == SOCKET_ERROR)
    {
        std::cout << "Can't connect to server!\n";
        closesocket(ConnectSocket);
        freeaddrinfo(result);
        WSACleanup();
        ConnectSocket = INVALID_SOCKET;
        return 1;
    }

    freeaddrinfo(result);

    if (ConnectSocket == INVALID_SOCKET)
    {
        std::cout << "Server unavailable!\n";
        WSACleanup();
        return 1;
    }

    //--------------------------------File handling-----------------------------------------
    
    partnerSocket = ConnectSocket;
    signal(SIGINT, signal_handler);
    std::vector<File> server_database = receiveListofFile(ConnectSocket);
    std::cout << "The list of file that server has: \n"; 
    printListofFile(server_database);
    
    std::vector<File> client_database = readClientFile("input.txt");
    std::cout << "---------Requesting file from client:\n";
    printClientList(client_database);

    //std::cout << "---- Sending new list to server and downloading files\n";
    //startPos = getCurrentCursorLinePosition();
    int baseY = startPos.Y;
    ////downloadFileFromServer(client_database, ConnectSocket);
    if(!downloadFileFromServer2(client_database, ConnectSocket)) std::cout << "The whole send to client and downloading data is failed\n";

    while (true)
    {
        Sleep(3000);
        std::vector<File> new_c_database = readClientFile("input.txt");

        if (new_c_database.size() > 0)
        {
            baseY = startPos.Y;
            downloadFileFromServer2(new_c_database, ConnectSocket);
        }
        std::cout << "Waiting\n";
    }


    closesocket(ConnectSocket);
    WSACleanup();
    return 0;
}