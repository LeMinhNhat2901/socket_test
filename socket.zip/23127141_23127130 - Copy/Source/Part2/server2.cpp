#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <winsock2.h> //---contain most of winsock function, struct,...
#include <ws2tcpip.h> //---definitions introduced in the winsock2 protocol for TCPIP
#include <iostream>
#include <iphlpapi.h> //---use if app using IP Helper APIs, place after the winsock2.h line
#include <windows.h>
#include <fstream>
#include <thread>
#include <vector>
#include <sstream>
#include <stdlib.h>
#include <cstring>
#define INPUT_FOLDER "Input\\"

//-----------------------------------------

const char* DEFAULT_PORT = "27019"; //--port for client connect
const int DEFAULT_BUFLEN = 512; 
const int NORMAL_BUFLEN= 10000; // 10KB
const int MEDIUM_BUFLEN = 20000; // 20KB 
const int HIGH_BUFLEN = 40000; // 40KB 
const int CRITICAL_BUFLEN = 100000; // 100KB
const int SEND_BUFLEN = 400000; // 400KB

struct File
{
    char* filename;
    int sizeMB;
    char* status;
};


std::vector<File> readFile(const char* filename) {
    std::ifstream fin(filename);
    if (!fin.is_open()) {
        std::cerr << "Failed to open list or server file list not exist\n";
        return {};
    }

    std::vector<File> database;
    std::string line;
    while (getline(fin, line)) {
        std::istringstream iss(line);
        std::string fileNameStr, sizeStr, statusStr;

        if (!(iss >> fileNameStr >> sizeStr)) {
            continue; // Skip lines that do not match the format
        }

        File data;
        data.filename = new char[fileNameStr.size() + 1];
        strcpy(data.filename, fileNameStr.c_str());

        data.sizeMB = std::stoi(sizeStr.substr(0, sizeStr.size() - 2)); // Assuming size is in "MB"

        database.push_back(data);
    }

    fin.close();
    return database;
}

void printListofFile(std::vector<File> database)
{
    for (int i = 0; i < database.size(); ++i)
    {
        std::cout << database[i].filename << ' ' << database[i].sizeMB << "MB\n";
    }
}

bool sendMessage(const char* message, SOCKET Partner) {
    int messageLength = static_cast<int>(std::strlen(message)) + 1;
    int lengthToSend = htonl(messageLength); // Convert length to network byte order

    // Send length of the message
    int iResult = send(Partner, (char*)&lengthToSend, sizeof(lengthToSend), 0);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Send length failed with error: " << WSAGetLastError() << '\n';
        closesocket(Partner);
        WSACleanup();
        return false;
    }

    // Send the actual message
    iResult = send(Partner, message, messageLength, 0);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Send message failed with error: " << WSAGetLastError() << '\n';
        closesocket(Partner);
        WSACleanup();
        return false;
    }
    return true;
}


bool sendInt(int num, SOCKET Partner) 
{
    int iResult = send(Partner, (char*)&num, sizeof(num), 0);
    
    if (iResult == SOCKET_ERROR) 
    {
        std::cerr << "sendInt() failed: " << WSAGetLastError() << '\n';
        return false;
    }
    return true;
}

void announceListofFile(const char* filename, SOCKET Partner, std::vector<File>& database) 
{
    int size = database.size();
    sendInt(size, Partner);

    for (int i = 0; i < database.size(); ++i) 
    {
        bool resultMsg = sendMessage(database[i].filename, Partner);
        bool resultSize = sendInt(database[i].sizeMB, Partner);
        if (!resultMsg || !resultSize) 
        {
            std::cerr << "Sending list of file failed\n";
            return;
        }
    }
}


char* receiveMessage(SOCKET Partner) 
{
    int messageLength;
    int iResult = recv(Partner, (char*)&messageLength, sizeof(messageLength), 0);
    if (iResult <= 0) 
    {
        std::cerr << "recvMsg() failed for length: " << WSAGetLastError() << '\n';
        return nullptr;
    }
    messageLength = ntohl(messageLength); // Convert from network byte order

    char* buffer = new char[messageLength];
    iResult = recv(Partner, buffer, messageLength, 0);
    if (iResult <= 0) {
        std::cerr << "recvMsg() failed for message: " << WSAGetLastError() << '\n';
        delete[] buffer;
        return nullptr;
    }
    return buffer;
}

int receiveInt(SOCKET Partner) 
{
    int num;
    int iResult = recv(Partner, (char*)&num, sizeof(num), 0);
    if (iResult == SOCKET_ERROR) 
    {
        std::cerr << "recv() int failed: " << WSAGetLastError() << '\n';
        return -1;
    }
    return num;
}

void sendSize(SOCKET ClientSocket, const std::string& filename)
{
    std::string input_path = std::string(INPUT_FOLDER) + filename;
    std::ifstream file(input_path, std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Failed to open file: " << filename << '\n';
        file.close();
        return;
    }
    
    // Send file size first
    file.seekg(0, std::ios::end);
    std::streampos fileSize = file.tellg();
    file.seekg(0, std::ios::beg);

    int size = static_cast<int>(fileSize);
    sendInt(size, ClientSocket); 
    std::cout << filename << " size: " << size << '\n';
    file.close();
    return;
}

int getSize(char* filename)
{
    std::string input_path = std::string(INPUT_FOLDER) + filename;
    std::ifstream file(input_path, std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Failed to open file: " << filename << '\n';
        file.close();
        return 0;
    }
    
    // Send file size first
    file.seekg(0, std::ios::end);
    std::streampos fileSize = file.tellg();
    file.seekg(0, std::ios::beg);

    int size = static_cast<int>(fileSize);
    file.close();
    return size;
}

bool isAllFileSent(std::vector<bool> list)
{
    for (bool val: list)
        if (!val) return false;
    return true;
}

void sendFilesInSingleBuffer(SOCKET ClientSocket, std::vector<std::pair<char*, int>> fileList) {
    char* mainBuffer = new char[SEND_BUFLEN];
    int offset = 0;
    std::vector<bool> isDone(fileList.size(), false);
    std::vector<int> tracking(fileList.size(), 0), fileBytesToSend, indexOfFile;

    while(!isAllFileSent(isDone)) //if all file is done, finish sending
    {
        for (int i = 0; i < fileList.size(); ++i)
        {
            if (!isDone[i])
            {
                int fileSize = getSize(fileList[i].first); 
                indexOfFile.push_back(i);

                std::string input_path = std::string(INPUT_FOLDER) + fileList[i].first;
                std::ifstream file(input_path, std::ios::binary);
                int chunkSize = fileList[i].second;
                //bytesToRead = chunk size or the remained size of the buffer
                //or the remained size of the file
                int bytesToRead = std::min(chunkSize, SEND_BUFLEN - offset);
                bytesToRead = std::min(bytesToRead, fileSize - tracking[i]);
                //continue at previous position;
                file.seekg(tracking[i], std::ios::beg);
                file.read(mainBuffer + offset, bytesToRead);

                tracking[i] += bytesToRead; fileBytesToSend.push_back(bytesToRead);
                if (tracking[i] == fileSize) 
                {
                    std::cout << fileList[i].first << " done\n";
                    isDone[i] = true;
                }
                offset += bytesToRead;

                //If buffer is full, send it to the client
                if (offset == SEND_BUFLEN)
                {
                    //send the size of the fileBytesToSend, 
                    //also number of files inside the buffer
                    sendInt(fileBytesToSend.size(), ClientSocket);
                    //then send the index of File and number of bytes 
                    for (int i = 0; i < fileBytesToSend.size(); ++i)
                    {
                        if(!sendInt(indexOfFile[i], ClientSocket))
                            std::cerr << "Failed sending indexOfFile\n";
                        if(!sendInt(fileBytesToSend[i], ClientSocket))
                            std::cerr << "Failed sending fileBytesToSend\n";
                        //std::cout << fileList[indexOfFile[i]].first << " : " << fileBytesToSend[i] << '\n';
                    }

                    //finally send the buffer
                    int bytesSent = send(ClientSocket, mainBuffer, SEND_BUFLEN, 0);
                    if (bytesSent == SOCKET_ERROR) 
                    {
                        std::cerr << "send() failed: " << WSAGetLastError() << '\n';
                        file.close();
                        delete[] mainBuffer;
                        return;
                    }
                    offset = 0; // Reset offset for the next set of chunks
                    file.close();
                    break;
                }
                file.close();
            }
        }
        if (offset == 0)
        {
            //std::cout << "clearing vectors \n";
            fileBytesToSend.clear();
            indexOfFile.clear();
        }
    }

    // Send any remaining data in the buffer
    if (offset > 0) 
    {
        sendInt(fileBytesToSend.size(), ClientSocket);
        //then send the index of File and number of bytes 
        for (int i = 0; i < fileBytesToSend.size(); ++i)
        {
            if(!sendInt(indexOfFile[i], ClientSocket))
                std::cerr << "Failed sending indexOfFile\n";
            if(!sendInt(fileBytesToSend[i], ClientSocket))
                std::cerr << "Failed sending fileBytesToSend\n";
            //std::cout << fileList[i].first << " : " << fileBytesToSend[i] << '\n';
        }
        int bytesSent = send(ClientSocket, mainBuffer, offset, 0);
        if (bytesSent == SOCKET_ERROR) 
        {
            std::cerr << "send() failed: " << WSAGetLastError() << '\n';
        }
    }

    delete[] mainBuffer;
}


int getBufflenFromStatus(char* status)
{
    int size = 0;
    if (strcmp(status, "CRITICAL") == 0) size = CRITICAL_BUFLEN;
    else if (strcmp(status, "HIGH") == 0) size = HIGH_BUFLEN;
    else if (strcmp(status,"MEDIUM") == 0) size = MEDIUM_BUFLEN;
    else if (strcmp(status,"NORMAL") == 0) size = NORMAL_BUFLEN;
    return size;
}

bool isFileNameExist(char* filename, std::vector<File> database)
{
    for (int i = 0; i < database.size(); ++i)
    {
        if (strcmp(filename, database[i].filename) == 0) return true;
    }
    return false;
}

void handleClient2(SOCKET ClientSocket, std::vector<File> database)
{
    // Assuming a fixed number of files to be received and sent
    int fileCount = receiveInt(ClientSocket);
    
    std::vector<std::pair<char*, int>> fileList;
    for (int i = 0; i < fileCount; ++i)
    {
        //receive filename
        char* filename = receiveMessage(ClientSocket);
        if (filename == nullptr)
        {
            std::cerr << "Error receiving filename from client\n";
            closesocket(ClientSocket);
            return;
        }
        
        //receive Status -> chunk length for the file
        int chunkSize = getBufflenFromStatus(receiveMessage(ClientSocket));
        if (chunkSize <= 0)        
        {
            std::cerr << "Invalid chunk size or file name\n";
            delete[] filename;
            closesocket(ClientSocket);
            return;
        }

        if (isFileNameExist(filename, database))
        {
            fileList.emplace_back(filename, chunkSize);
        
            //sending the size of file for client
            sendInt(getSize(fileList[i].first), ClientSocket);
            //sendSize(ClientSocket, filename);

            std::cout << "Requested file: " << fileList[i].first << " with chunk size: "  << chunkSize << '\n';
        }
        else
        {
            sendInt(0, ClientSocket);
            std::cout << filename << " is not exist in database -> no download for this file \n";
        }
    }

    std::cout << "---Sending---\n";
    sendFilesInSingleBuffer(ClientSocket, fileList);

    int iResult = shutdown(ClientSocket, SD_SEND);
    if (iResult == SOCKET_ERROR)
    {
        std::cout << "Shutdown failed: " << WSAGetLastError() << '\n';
        closesocket(ClientSocket);
        WSACleanup();
        return;
    }
    
    closesocket(ClientSocket);
}

void cleanupFiles(std::vector<File>& database) 
{
    for (auto& file : database) {
        delete[] file.filename;
        delete[] file.status;
    }
    database.clear();
}

void cleanupFileBuff(std::vector<std::pair<char*, int>> list)
{
    for (auto& file : list)
    {
        delete[] file.first;
    }
    list.clear();
}

void handleThread(SOCKET ClientSocket, std::vector<File> database)
{
    while(ClientSocket != INVALID_SOCKET)
        {
            std::cout << "-----receive new client list and send to client\n";

            handleClient2(ClientSocket, database);
        }   
}

int main()
{
    std::cout << "----------------------Server-------------\n";
    std::vector<File> database = readFile("list_input.txt");
    printListofFile(database);
    //std::vector<std::pair<char*, int>> prior_database = listFileandBuff(database);
    
    //--create WSA object 
    WSADATA wsaData;

    int iResult;
    //--- initialize winsock and check if init complete
    //--- WSAStartup function use WS2_32.dll.
    //--- MAKEWORD for WSA use the 2.2 version of winsock
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData); //result of the start up
    if (iResult != 0)
    {
        std::cout << "WSAStartup failed: " << iResult << '\n';
        return 1;
    }

    struct addrinfo *result = NULL, hints;
    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET; //--specify IPv4 address
    hints.ai_socktype = SOCK_STREAM; //--specify stream socket
    hints.ai_protocol = IPPROTO_TCP;//--use TCP Protocol
    hints.ai_flags = AI_PASSIVE; //--use for <bind> function
    

    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
    if (iResult != 0)
    {
        std::cout << "Getaddrinfo failed: " << iResult << '\n';
        WSACleanup();
        return 1;
    }

    SOCKET ListenSocket = INVALID_SOCKET;//server socket to listen client
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);   

    //---check is socket valid
    if (ListenSocket == INVALID_SOCKET)
    {
        std::cout << "Error at socket(): " << WSAGetLastError() << '\n';
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    //---bind the listensocket to the system client network address
    iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR)
    {
        std::cout << "Bind failed with error: " << WSAGetLastError() << '\n';
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }
    
    //---deallocated because does not need of the result
    freeaddrinfo(result);

    //---listen request information in the listensocket 
    if (listen(ListenSocket, SOMAXCONN) == SOCKET_ERROR)
    //---SOMAXCONN is a backlog parameter, it instruct winsock 
    //---provide the max number of connection in queue
    {
        std::cout << "Listen failed with error: " << WSAGetLastError() << '\n';
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    //---acepting the connection (single connection each time)

   
    SOCKET ClientSocket; //---temp client socket
    ClientSocket = INVALID_SOCKET;
    
    while(true)
    {
        //---the accept function contain a loop to verify
        //whether to connected or not.
        ClientSocket = accept(ListenSocket, NULL, NULL);
        if (ClientSocket == INVALID_SOCKET)
        {
            std::cout << "accept failed" << WSAGetLastError() << '\n';
            closesocket(ListenSocket);
            WSACleanup();
            return 1;
        }

        std::cout << "Client connected!\n";
        std::cout << "Sending list to Client\n";
        announceListofFile("serverlist.txt", ClientSocket, database);

        // ------------------------------SERVER WORKING PROCESS-------------------------------------

        while(ClientSocket != INVALID_SOCKET)
        {
            std::cout << "-----receive new client list and send to client\n";

            handleClient2(ClientSocket, database);
        }
        
       // std::thread clientThread(handleThread, ClientSocket, database);
        //std::thread clientThread(handleClient, ClientSocket);
        //clientThread.detach();
        //std::cout << "----Sending complete!------\n";
        //clientThread.join();
        std::cout << "Client disconected\n";
    }
   //----disconnecting the server and client connection
   //----also shutdown the socket


    //---clean up
    cleanupFiles(database);
    closesocket(ListenSocket);
    WSACleanup();
    return 0;
}